import { createAboutTemplate } from '../../templates';

const AboutPage = {
  render() {
    return createAboutTemplate();
  },

  afterRender() {
  },
};

export default AboutPage;